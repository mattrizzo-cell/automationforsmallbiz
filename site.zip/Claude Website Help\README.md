# Automation for Small Businesses

This is a landing page for a business focused on helping small businesses with automation to save time, money, and improve efficiency.

## Features

- Home page with hero section
- About page
- Contact page with form

## How to run

Open `index.html` in your web browser or upload to your hosting.

## Customization

Edit the HTML files, CSS, and JS as needed. Replace placeholder images in the `images/` folder with your actual images.